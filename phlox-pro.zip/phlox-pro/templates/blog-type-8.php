<?php
/**
 * Template Name: Land Blog 
 *
 * 
 * @package    Auxin
 * @author     averta (c) 2014-2025
 * @link       http://averta.net
 */

locate_template( 'templates/blog-main.php', true );
